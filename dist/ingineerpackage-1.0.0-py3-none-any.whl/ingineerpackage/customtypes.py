import typing

Number = typing.Union[int, float]